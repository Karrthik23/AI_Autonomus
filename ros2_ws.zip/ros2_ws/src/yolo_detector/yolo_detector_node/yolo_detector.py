#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import Header
from cv_bridge import CvBridge
import torch
import cv2
import numpy as np

from yolo_detector.msg import BoundingBox, BoundingBoxes


class YoloDetectorNode(Node):
    def __init__(self):
        super().__init__('yolo_detector')

        # Load YOLOv5 model (edit path if needed)
        self.model = torch.hub.load('ultralytics/yolov5', 'custom', path='models/yolov5.pt', force_reload=True)
        self.model.eval()

        # ROS setup
        self.bridge = CvBridge()
        self.subscription = self.create_subscription(Image, '/image_raw', self.image_callback, 10)
        self.annotated_pub = self.create_publisher(Image, '/yolo/annotated_image', 10)
        self.boxes_pub = self.create_publisher(BoundingBoxes, '/yolo/detections', 10)

        self.get_logger().info("YOLO Detector Node initialized.")

    def image_callback(self, msg):
        try:
            # Convert ROS image to OpenCV image
            cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        except Exception as e:
            self.get_logger().error(f"CVBridge error: {e}")
            return

        # Run YOLO inference
        results = self.model(cv_image)

        # Get detection metadata
        detections = results.xyxy[0]  # tensor: (x1, y1, x2, y2, conf, cls)

        # Render boxes on image for visualization
        annotated_image = results.render()[0]

        # Prepare and publish the annotated image
        out_msg = self.bridge.cv2_to_imgmsg(annotated_image, encoding='bgr8')
        out_msg.header = msg.header
        self.annotated_pub.publish(out_msg)

        # Prepare and publish bounding boxes
        boxes_msg = BoundingBoxes()
        boxes_msg.header = msg.header

        for det in detections:
            x1, y1, x2, y2, conf, cls = det.tolist()
            bbox = BoundingBox()
            bbox.id = -1  # Optional tracking ID, not used now
            bbox.label = self.model.names[int(cls)]
            bbox.confidence = float(conf)
            bbox.xmin = int(x1)
            bbox.ymin = int(y1)
            bbox.xmax = int(x2)
            bbox.ymax = int(y2)
            boxes_msg.boxes.append(bbox)

        self.boxes_pub.publish(boxes_msg)


def main():
    print("YOLO detector node started.")
    rclpy.init()
    node = YoloDetectorNode()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()
