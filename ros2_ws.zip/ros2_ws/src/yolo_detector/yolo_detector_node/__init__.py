from .yolo_detector import main
