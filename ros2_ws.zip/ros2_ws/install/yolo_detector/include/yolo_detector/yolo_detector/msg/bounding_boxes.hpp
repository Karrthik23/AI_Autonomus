// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef YOLO_DETECTOR__MSG__BOUNDING_BOXES_HPP_
#define YOLO_DETECTOR__MSG__BOUNDING_BOXES_HPP_

#include "yolo_detector/msg/detail/bounding_boxes__struct.hpp"
#include "yolo_detector/msg/detail/bounding_boxes__builder.hpp"
#include "yolo_detector/msg/detail/bounding_boxes__traits.hpp"
#include "yolo_detector/msg/detail/bounding_boxes__type_support.hpp"

#endif  // YOLO_DETECTOR__MSG__BOUNDING_BOXES_HPP_
