// generated from rosidl_generator_c/resource/idl__type_support.c.em
// with input from yolo_detector:msg/BoundingBoxes.idl
// generated code does not contain a copyright notice

#include <string.h>

#include "rosidl_typesupport_interface/macros.h"
#include "yolo_detector/msg/detail/bounding_boxes__functions.h"
#include "yolo_detector/msg/detail/bounding_boxes__type_support.h"
#include "yolo_detector/msg/detail/bounding_boxes__struct.h"

#ifdef __cplusplus
extern "C"
{
#endif

#ifdef __cplusplus
}
#endif
