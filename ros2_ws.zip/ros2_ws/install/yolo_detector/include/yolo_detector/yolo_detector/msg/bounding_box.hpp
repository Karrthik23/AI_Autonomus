// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef YOLO_DETECTOR__MSG__BOUNDING_BOX_HPP_
#define YOLO_DETECTOR__MSG__BOUNDING_BOX_HPP_

#include "yolo_detector/msg/detail/bounding_box__struct.hpp"
#include "yolo_detector/msg/detail/bounding_box__builder.hpp"
#include "yolo_detector/msg/detail/bounding_box__traits.hpp"
#include "yolo_detector/msg/detail/bounding_box__type_support.hpp"

#endif  // YOLO_DETECTOR__MSG__BOUNDING_BOX_HPP_
