// generated from rosidl_generator_c/resource/idl__description.c.em
// with input from yolo_detector:msg/BoundingBox.idl
// generated code does not contain a copyright notice

#include "yolo_detector/msg/detail/bounding_box__functions.h"

ROSIDL_GENERATOR_C_PUBLIC_yolo_detector
const rosidl_type_hash_t *
yolo_detector__msg__BoundingBox__get_type_hash(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_type_hash_t hash = {1, {
      0x2d, 0x22, 0xc8, 0xbe, 0x15, 0x6e, 0xa3, 0x94,
      0x22, 0xc5, 0x86, 0x6c, 0xd1, 0x74, 0xae, 0xa3,
      0x12, 0x1b, 0xa1, 0x1a, 0x94, 0x02, 0x9b, 0xb6,
      0x16, 0xde, 0xcd, 0x0f, 0x2d, 0xc1, 0x00, 0x9b,
    }};
  return &hash;
}

#include <assert.h>
#include <string.h>

// Include directives for referenced types

// Hashes for external referenced types
#ifndef NDEBUG
#endif

static char yolo_detector__msg__BoundingBox__TYPE_NAME[] = "yolo_detector/msg/BoundingBox";

// Define type names, field names, and default values
static char yolo_detector__msg__BoundingBox__FIELD_NAME__id[] = "id";
static char yolo_detector__msg__BoundingBox__FIELD_NAME__label[] = "label";
static char yolo_detector__msg__BoundingBox__FIELD_NAME__confidence[] = "confidence";
static char yolo_detector__msg__BoundingBox__FIELD_NAME__xmin[] = "xmin";
static char yolo_detector__msg__BoundingBox__FIELD_NAME__ymin[] = "ymin";
static char yolo_detector__msg__BoundingBox__FIELD_NAME__xmax[] = "xmax";
static char yolo_detector__msg__BoundingBox__FIELD_NAME__ymax[] = "ymax";

static rosidl_runtime_c__type_description__Field yolo_detector__msg__BoundingBox__FIELDS[] = {
  {
    {yolo_detector__msg__BoundingBox__FIELD_NAME__id, 2, 2},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {yolo_detector__msg__BoundingBox__FIELD_NAME__label, 5, 5},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_STRING,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {yolo_detector__msg__BoundingBox__FIELD_NAME__confidence, 10, 10},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_FLOAT,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {yolo_detector__msg__BoundingBox__FIELD_NAME__xmin, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {yolo_detector__msg__BoundingBox__FIELD_NAME__ymin, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {yolo_detector__msg__BoundingBox__FIELD_NAME__xmax, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
  {
    {yolo_detector__msg__BoundingBox__FIELD_NAME__ymax, 4, 4},
    {
      rosidl_runtime_c__type_description__FieldType__FIELD_TYPE_INT32,
      0,
      0,
      {NULL, 0, 0},
    },
    {NULL, 0, 0},
  },
};

const rosidl_runtime_c__type_description__TypeDescription *
yolo_detector__msg__BoundingBox__get_type_description(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static bool constructed = false;
  static const rosidl_runtime_c__type_description__TypeDescription description = {
    {
      {yolo_detector__msg__BoundingBox__TYPE_NAME, 29, 29},
      {yolo_detector__msg__BoundingBox__FIELDS, 7, 7},
    },
    {NULL, 0, 0},
  };
  if (!constructed) {
    constructed = true;
  }
  return &description;
}

static char toplevel_type_raw_source[] =
  "int32 id                  \n"
  "string label              \n"
  "float32 confidence        \n"
  "int32 xmin\n"
  "int32 ymin\n"
  "int32 xmax\n"
  "int32 ymax";

static char msg_encoding[] = "msg";

// Define all individual source functions

const rosidl_runtime_c__type_description__TypeSource *
yolo_detector__msg__BoundingBox__get_individual_type_description_source(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static const rosidl_runtime_c__type_description__TypeSource source = {
    {yolo_detector__msg__BoundingBox__TYPE_NAME, 29, 29},
    {msg_encoding, 3, 3},
    {toplevel_type_raw_source, 125, 125},
  };
  return &source;
}

const rosidl_runtime_c__type_description__TypeSource__Sequence *
yolo_detector__msg__BoundingBox__get_type_description_sources(
  const rosidl_message_type_support_t * type_support)
{
  (void)type_support;
  static rosidl_runtime_c__type_description__TypeSource sources[1];
  static const rosidl_runtime_c__type_description__TypeSource__Sequence source_sequence = {sources, 1, 1};
  static bool constructed = false;
  if (!constructed) {
    sources[0] = *yolo_detector__msg__BoundingBox__get_individual_type_description_source(NULL),
    constructed = true;
  }
  return &source_sequence;
}
