// generated from rosidl_generator_c/resource/idl.h.em
// with input from yolo_detector:msg/BoundingBox.idl
// generated code does not contain a copyright notice

#ifndef YOLO_DETECTOR__MSG__BOUNDING_BOX_H_
#define YOLO_DETECTOR__MSG__BOUNDING_BOX_H_

#include "yolo_detector/msg/detail/bounding_box__struct.h"
#include "yolo_detector/msg/detail/bounding_box__functions.h"
#include "yolo_detector/msg/detail/bounding_box__type_support.h"

#endif  // YOLO_DETECTOR__MSG__BOUNDING_BOX_H_
