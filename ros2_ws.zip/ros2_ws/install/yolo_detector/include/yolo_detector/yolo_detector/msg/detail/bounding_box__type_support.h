// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from yolo_detector:msg/BoundingBox.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "yolo_detector/msg/bounding_box.h"


#ifndef YOLO_DETECTOR__MSG__DETAIL__BOUNDING_BOX__TYPE_SUPPORT_H_
#define YOLO_DETECTOR__MSG__DETAIL__BOUNDING_BOX__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "yolo_detector/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_yolo_detector
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  yolo_detector,
  msg,
  BoundingBox
)(void);

#ifdef __cplusplus
}
#endif

#endif  // YOLO_DETECTOR__MSG__DETAIL__BOUNDING_BOX__TYPE_SUPPORT_H_
