// generated from rosidl_generator_c/resource/idl__type_support.c.em
// with input from yolo_detector:msg/BoundingBox.idl
// generated code does not contain a copyright notice

#include <string.h>

#include "rosidl_typesupport_interface/macros.h"
#include "yolo_detector/msg/detail/bounding_box__functions.h"
#include "yolo_detector/msg/detail/bounding_box__type_support.h"
#include "yolo_detector/msg/detail/bounding_box__struct.h"

#ifdef __cplusplus
extern "C"
{
#endif

#ifdef __cplusplus
}
#endif
