// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from yolo_detector:msg/BoundingBox.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "yolo_detector/msg/bounding_box.h"


#ifndef YOLO_DETECTOR__MSG__DETAIL__BOUNDING_BOX__STRUCT_H_
#define YOLO_DETECTOR__MSG__DETAIL__BOUNDING_BOX__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

// Constants defined in the message

// Include directives for member types
// Member 'label'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/BoundingBox in the package yolo_detector.
typedef struct yolo_detector__msg__BoundingBox
{
  int32_t id;
  rosidl_runtime_c__String label;
  float confidence;
  int32_t xmin;
  int32_t ymin;
  int32_t xmax;
  int32_t ymax;
} yolo_detector__msg__BoundingBox;

// Struct for a sequence of yolo_detector__msg__BoundingBox.
typedef struct yolo_detector__msg__BoundingBox__Sequence
{
  yolo_detector__msg__BoundingBox * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} yolo_detector__msg__BoundingBox__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // YOLO_DETECTOR__MSG__DETAIL__BOUNDING_BOX__STRUCT_H_
