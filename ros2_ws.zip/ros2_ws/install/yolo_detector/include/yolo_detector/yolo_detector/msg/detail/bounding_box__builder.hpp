// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from yolo_detector:msg/BoundingBox.idl
// generated code does not contain a copyright notice

// IWYU pragma: private, include "yolo_detector/msg/bounding_box.hpp"


#ifndef YOLO_DETECTOR__MSG__DETAIL__BOUNDING_BOX__BUILDER_HPP_
#define YOLO_DETECTOR__MSG__DETAIL__BOUNDING_BOX__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "yolo_detector/msg/detail/bounding_box__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace yolo_detector
{

namespace msg
{

namespace builder
{

class Init_BoundingBox_ymax
{
public:
  explicit Init_BoundingBox_ymax(::yolo_detector::msg::BoundingBox & msg)
  : msg_(msg)
  {}
  ::yolo_detector::msg::BoundingBox ymax(::yolo_detector::msg::BoundingBox::_ymax_type arg)
  {
    msg_.ymax = std::move(arg);
    return std::move(msg_);
  }

private:
  ::yolo_detector::msg::BoundingBox msg_;
};

class Init_BoundingBox_xmax
{
public:
  explicit Init_BoundingBox_xmax(::yolo_detector::msg::BoundingBox & msg)
  : msg_(msg)
  {}
  Init_BoundingBox_ymax xmax(::yolo_detector::msg::BoundingBox::_xmax_type arg)
  {
    msg_.xmax = std::move(arg);
    return Init_BoundingBox_ymax(msg_);
  }

private:
  ::yolo_detector::msg::BoundingBox msg_;
};

class Init_BoundingBox_ymin
{
public:
  explicit Init_BoundingBox_ymin(::yolo_detector::msg::BoundingBox & msg)
  : msg_(msg)
  {}
  Init_BoundingBox_xmax ymin(::yolo_detector::msg::BoundingBox::_ymin_type arg)
  {
    msg_.ymin = std::move(arg);
    return Init_BoundingBox_xmax(msg_);
  }

private:
  ::yolo_detector::msg::BoundingBox msg_;
};

class Init_BoundingBox_xmin
{
public:
  explicit Init_BoundingBox_xmin(::yolo_detector::msg::BoundingBox & msg)
  : msg_(msg)
  {}
  Init_BoundingBox_ymin xmin(::yolo_detector::msg::BoundingBox::_xmin_type arg)
  {
    msg_.xmin = std::move(arg);
    return Init_BoundingBox_ymin(msg_);
  }

private:
  ::yolo_detector::msg::BoundingBox msg_;
};

class Init_BoundingBox_confidence
{
public:
  explicit Init_BoundingBox_confidence(::yolo_detector::msg::BoundingBox & msg)
  : msg_(msg)
  {}
  Init_BoundingBox_xmin confidence(::yolo_detector::msg::BoundingBox::_confidence_type arg)
  {
    msg_.confidence = std::move(arg);
    return Init_BoundingBox_xmin(msg_);
  }

private:
  ::yolo_detector::msg::BoundingBox msg_;
};

class Init_BoundingBox_label
{
public:
  explicit Init_BoundingBox_label(::yolo_detector::msg::BoundingBox & msg)
  : msg_(msg)
  {}
  Init_BoundingBox_confidence label(::yolo_detector::msg::BoundingBox::_label_type arg)
  {
    msg_.label = std::move(arg);
    return Init_BoundingBox_confidence(msg_);
  }

private:
  ::yolo_detector::msg::BoundingBox msg_;
};

class Init_BoundingBox_id
{
public:
  Init_BoundingBox_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_BoundingBox_label id(::yolo_detector::msg::BoundingBox::_id_type arg)
  {
    msg_.id = std::move(arg);
    return Init_BoundingBox_label(msg_);
  }

private:
  ::yolo_detector::msg::BoundingBox msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::yolo_detector::msg::BoundingBox>()
{
  return yolo_detector::msg::builder::Init_BoundingBox_id();
}

}  // namespace yolo_detector

#endif  // YOLO_DETECTOR__MSG__DETAIL__BOUNDING_BOX__BUILDER_HPP_
